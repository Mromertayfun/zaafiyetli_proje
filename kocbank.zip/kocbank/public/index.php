<!-- dashboard.php -->
<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>koc-Home</title>
    <link rel="stylesheet" href="../assets/css/index.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            koc
        </div>
        <ul class="list">
            <li class="item"><a href="index.php"class="active" >ana sayfa</a></li>
            <li class="item"><a href="about.php">hakkımızda</a></li>
            <li class="item"><a href="login.php" >hesabım</a></li>
            <li class="item"><a href="support.php">destek</a></li>
            <li class="item"><a href="faq.php">sss</a></li>
        </ul>
        <?php
            if (isset($_SESSION["authenticated"]) && $_SESSION["authenticated"]){
                echo '<a href="login.php" ><button type="button" class="btn">Logout</button></a>';
            }else{
                echo '<a href="login.php" ><button type="button" class="btn">Login</button></a>';
            }
        ?>
    </nav>
    <div class="body">
        <div class="head">
            <h1>Welcome to koc: koc  Bank</h1>
            <h3>
                koç olarak biz bir bankadan daha fazlasıyız; Hayallerinize giden yolculukta finansal ortağınızız. Yarım yüzyılı aşkın bir mükemmellik mirasıyla, finansal inovasyonun ön saflarında yer aldık, bireylerin ve işletmelerin hedeflerine ulaşmalarına yardımcı olduk.
                <br><br>
                Size olan bağlılığımız sarsılmazdır; güvene, şeffaflığa ve kişiselleştirilmiş hizmete dayanmaktadır. İster tasarruf etmek, ister yatırım yapmak veya ödünç almak istiyor olun, benzersiz ihtiyaçlarınızı karşılamak üzere tasarlanmış geniş bir çözüm yelpazesine sahibiz.
                <br><br>
                Kapsamlı bankacılık hizmetlerimizi keşfetmek, özel ekibimizle tanışmak ve yeni finansal boyutlara ulaşmanıza nasıl yardımcı olabileceğimizi öğrenmek için web sitemizi keşfedin. Sizin istekleriniz bizim önceliklerimizdir ve birlikte daha parlak bir finansal gelecek inşa edebiliriz.
                <br><br>
                Finansal yolculuğunuzun başladığı koç'a hoş geldiniz.
            </h3>
            <!-- <button type="button" class="btn">Sign Up</button> -->
        </div>
    </div>
</body>
</html>
